# Radius Raid - GitHub Actions APK Builder

## Como usar (passo a passo)

### 1. Criar repositório no GitHub
- Acesse github.com e faça login
- Clique em "New repository"
- Nome: `radius-raid`
- Deixe como **Public** ou **Private**
- Clique em "Create repository"

### 2. Enviar os arquivos pelo celular (Termux)

Cole estes comandos no Termux:

```bash
pkg install git -y
```

```bash
cd ~
git clone https://github.com/SEU_USUARIO/radius-raid.git
```

Copie os arquivos deste ZIP para dentro da pasta clonada:
```bash
cp -r /caminho/dos/arquivos/* ~/radius-raid/
```

```bash
cd ~/radius-raid
git config user.email "seu@email.com"
git config user.name "Seu Nome"
git add .
git commit -m "Primeiro commit"
git push origin main
```

> Quando pedir senha, use um **Personal Access Token** do GitHub
> (Settings → Developer settings → Personal access tokens → Generate new token)

### 3. Acompanhar o build
- No GitHub, clique na aba **"Actions"**
- Você verá o workflow rodando automaticamente
- Aguarde ~5 minutos

### 4. Baixar o APK
- Clique no workflow concluído (✅)
- Role até **"Artifacts"**
- Clique em **"RadiusRaid-APK"** para baixar

---

## Estrutura do projeto

```
radius-raid/
├── .github/
│   └── workflows/
│       └── build.yml      ← Automação do build
├── js/                    ← Scripts do jogo
├── index.html             ← Jogo principal
├── capacitor.config.json  ← Config do app
├── package.json           ← Dependências
└── .gitignore
```

---

## Para gerar um novo APK
Basta fazer qualquer `git push` para a branch `main`.
Ou vá em Actions → "Build Android APK" → "Run workflow".
